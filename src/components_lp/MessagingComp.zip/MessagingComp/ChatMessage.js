

import React, { useState } from 'react';
import ChatWindow from './ChatWindow';
import MessagingSidebar from './MessagingSidebar';

const ChatMessage = () => {
  const currentUser = localStorage.getItem('userId');
  const [chatDetails, setChatDetails] = useState(null);

  return (
    <div className="flex h-screen">
      <MessagingSidebar currentUser={currentUser} setChatWith={setChatDetails} />
      {chatDetails && <ChatWindow chatDetails={chatDetails} />}
    </div>
  );
};

export default ChatMessage;



