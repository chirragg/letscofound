// // Card.js

// import React from "react";

// const Card = () => {
//   return (
//     <div className="max-w-sm rounded overflow-hidden shadow-lg relative">
//       {/* Background Image */}
//       <img
//         className="w-full h-full object-cover rounded"
//         src="/images/cardimage.jpeg"
//         alt="Card Background"
//       />
//       {/* Hovering Text */}
//       <div className="absolute top-0 left-0 w-full h-full bg-black opacity-0 hover:opacity-75 transition duration-300 ease-in-out flex items-center justify-center">
//         <p className="text-white text-lg font-semibold">See who all are Collaborating</p>
//       </div>
//     </div>
//   );
// };

// export default Card;
